class DataUser{
  String name;
  String id;
  String email;

  DataUser({this.name, this.id, this.email});
}