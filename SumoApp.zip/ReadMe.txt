New Features:

• *Favorite Screen has been done*
• *Individual accounts can be created*
• *Accounts can be deleted by users' choice*
• *Remember Me button can be used*


• Database Operations
  - Created 3 tables(Upcoming(Insertion,Update),Favorites(Insertion,Deletion),HomeScreen Movies(Insertion))

• FireBase Operations
  - Created Authentication Service (Insertion,Deletion)
  - Created 2 Collections (User information(Insertion,Deletion), User Favorites List(Update))

• Remember Me Process
  - User can keep mail and password information in Log-in screen



