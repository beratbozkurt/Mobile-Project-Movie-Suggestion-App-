import 'package:flutter/material.dart';
import 'package:sumo_login/login.dart';
import 'package:sumo_login/movie_list.dart';
import 'MovieDetails.dart';
import 'homescreen.dart';

void main() {

  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => login(),
      '/home': (context) => HomeScreen(),
    },
    debugShowCheckedModeBanner: false,
  ));
}

