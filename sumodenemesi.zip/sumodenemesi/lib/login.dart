import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'homescreen.dart';

class login extends StatefulWidget {
  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  // Variables
  TextEditingController _mailController = new TextEditingController();
  TextEditingController _nameController = new TextEditingController();
  TextEditingController _passwordController = new TextEditingController();
  bool login = true;
  List<bool> c = [true, false];
  bool rm = false;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Stack(
        children: [
          Image.asset(
            "asset/login.jpg",
            height: size.height,
            width: size.width,
            fit: BoxFit.cover,
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            body: SizedBox.expand(
              child: ListView(
                children: [
                  SizedBox(
                    height: size.height * 0.04,
                  ),
                  Container(
                    height: size.height * 0.25,
                    child: Image.asset(
                      "asset/icon.png",
                      height: size.height * 0.024,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        child: card("Log in", c[0], size),
                        onTap: () {
                          setState(() {
                            c[1] = false;
                            c[0] = true;
                            login = true;
                          });
                        },
                      ),
                      GestureDetector(
                        child: card("Sign up", c[1], size),
                        onTap: () {
                          setState(() {
                            c[0] = false;
                            c[1] = true;
                            login = false;
                          });
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.04,
                  ),
                  login
                      ? Column(
                          children: [
                            info("Log in", size),
                            Row(
                              children: [
                                SizedBox(
                                  width: size.width * 0.07,
                                ),
                                Checkbox(
                                  activeColor: Colors.amber,
                                  value: rm,
                                  onChanged: (newValue) {
                                    setState(() {
                                      rm = !rm;
                                    });
                                  },
                                ),
                                Text(
                                  "Remember me",
                                  style: TextStyle(
                                      color: CupertinoColors
                                          .extraLightBackgroundGray,
                                      fontSize: 14),
                                ),
                              ],
                            )
                          ],
                        )
                      : Column(
                          children: [
                            Container(
                              width: size.width * 0.83,
                              child: TextField(
                                style: TextStyle(color: Colors.white),
                                controller: _mailController,
                                obscureText: false,
                                decoration: InputDecoration(
                                  labelText: "Mail",
                                  labelStyle: TextStyle(
                                    color: CupertinoColors
                                        .extraLightBackgroundGray,
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: CupertinoColors.systemYellow,
                                        width: 1.0,
                                      ),
                                      borderRadius:
                                          BorderRadius.circular(15.0)),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: CupertinoColors.systemYellow,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.04),
                            info("Sign up", size),
                          ],
                        )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  card(String s, bool c, Size size) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(50, 0, 50, 0),
      child: Container(
        height: size.height * 0.1,
        width: size.width * 0.18,
        child: Column(
          children: [
            Text(
              s,
              style: TextStyle(
                fontSize: 15.0,
                color: c ? Colors.amber : Colors.white,
              ),
            ),
            Divider(
              color: c ? Colors.amber : Colors.white,
            ),
          ],
        ),
      ),
    );
  }

  info(String s, Size size) {
    return Column(
      children: [
        Container(
          width: size.width * 0.83,
          child: TextField(
            controller: _nameController,
            obscureText: false,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              labelText: "Username",
              labelStyle: TextStyle(
                color: CupertinoColors.extraLightBackgroundGray,
              ),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: CupertinoColors.systemYellow,
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(15.0)),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: CupertinoColors.systemYellow,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(20.0),
              ),
            ),
          ),
        ),
        SizedBox(height: size.height * 0.04),
        Container(
          width: size.width * 0.83,
          child: TextField(
            controller: _passwordController,
            obscureText: false,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              labelText: "Password",
              labelStyle: TextStyle(
                color: CupertinoColors.extraLightBackgroundGray,
              ),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: CupertinoColors.systemYellow,
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(15.0)),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: CupertinoColors.systemYellow,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(20.0),
              ),
            ),
          ),
        ),
        SizedBox(
          height: size.height * 0.05,
        ),
        Container(
          width: size.width * 0.2,
          height: size.height * 0.06,
          child: Center(
            child: RaisedButton(
              color: Colors.transparent.withOpacity(0.2),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0),
                  side: BorderSide(color: CupertinoColors.black)),
              child: Text(
                s,
                style: TextStyle(
                  color: CupertinoColors.extraLightBackgroundGray,fontSize: size.width*0.035
                ),
              ),
              onPressed: () {
                setState(() {
                  Navigator.pushReplacementNamed(context, '/home');
                });
              },
            ),
          ),
        ),
      ],
    );
  }
}
