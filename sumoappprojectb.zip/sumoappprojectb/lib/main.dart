import 'package:flutter/material.dart';
import 'package:sumoappprojectb/local_notification.dart';
import 'package:workmanager/workmanager.dart';
import 'login.dart';
import 'package:firebase_core/firebase_core.dart';
import 'loading.dart';
import 'databaseHelper.dart';

void callbackDispatcher() {
  Workmanager.executeTask((taskName, inputData) async {

    final dbHelper = DatabaseHelper.instance;

    var data =  await movie.fetchMovie("upcoming");
    if(DatabaseHelper.tableUpcoming.isNotEmpty) {
      for (int index = 0; index < 6; index++) {
        bool tf = await dbHelper.find(
            data[index]["id"].toString(), DatabaseHelper.tableUpcoming,
            DatabaseHelper.columnMovieID);
        if (tf) {
          await LocalNotification.setNotification(data[index]["title"]);
          break;
        }
      }
    }
    return Future.value(true);
  });
}

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();

  await Workmanager.initialize(callbackDispatcher);
  await Workmanager.registerPeriodicTask("Background Task", "Background Task",
      frequency: Duration(minutes: 15),
      initialDelay: Duration(seconds: 10));
  await Firebase.initializeApp();


  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => login(),
    },
    debugShowCheckedModeBanner: false,
  ));

}
